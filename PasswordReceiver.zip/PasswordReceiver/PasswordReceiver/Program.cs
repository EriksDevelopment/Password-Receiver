﻿using System;
using System.Text;
using System.Threading;
using System.Collections.Generic;
namespace PasswordReceiver
{
    class Program
    {
        static bool run = true;
        static void Main(string[] args)
        {
            while (run)
            {
                Console.Clear();
                Console.WriteLine("=== PASSWORD RECEIVER ===");
                int length = GetPasswordLength();
                bool includeLetters = Ask("Include letters (a - z, A - Z)?");
                bool includeNumbers = Ask("Include numbers (0 - 9)?");
                bool includeSymbols = Ask("Include symbols (!@#$%^&*)?");

                string password = GeneratePassword(length, includeLetters, includeNumbers, includeSymbols);
                if (!string.IsNullOrEmpty(password))
                    Console.WriteLine($"\nYour password: {password}");
                while (true)
                {
                    Console.WriteLine("\n[y] Generate new password");
                    Console.WriteLine("[n] Quit");
                    Console.Write("Choose (y/n): ");
                    string choice = Console.ReadLine().Trim().ToLower();
                    if (choice == "y")
                        break;
                    else if (choice == "n")
                    {
                        Console.WriteLine("Quitting...");
                        Thread.Sleep(1000);
                        run = false;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid option! You must type 'y' or 'n'.");
                    }
                }
            }
        }
        static int GetPasswordLength()
        {
            int length;
            while (true)
            {
                Console.Write("Enter desired password length: ");
                if (int.TryParse(Console.ReadLine(), out length) && length > 0)
                    return length;

                Console.WriteLine("Invalid input, try again!");
            }
        }
        static bool Ask(string message)
        {
            while (true)
            {
                Console.Clear();
                Console.Write($"{message} (y/n): ");
                string input = Console.ReadLine().Trim().ToLower();

                if (input == "y")
                    return true;
                else if (input == "n")
                    return false;
                else
                    Console.WriteLine("Invalid input! Please enter only 'y' or 'n'.");
                Thread.Sleep(1000);
            }
        }
        static string GeneratePassword(int length, bool letters, bool numbers, bool symbols)
        {
            const string letterChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string numberChars = "0123456789";
            const string symbolChars = "!@#$%^&*()-_=+[]{}<>?";
            List<char> charPool = new List<char>();
            List<char> guaranteedChars = new List<char>();
            Random rand = new Random();
            if (letters)
            {
                charPool.AddRange(letterChars);
                guaranteedChars.Add(letterChars[rand.Next(letterChars.Length)]);
            }
            if (numbers)
            {
                charPool.AddRange(numberChars);
                guaranteedChars.Add(numberChars[rand.Next(numberChars.Length)]);
            }
            if (symbols)
            {
                charPool.AddRange(symbolChars);
                guaranteedChars.Add(symbolChars[rand.Next(symbolChars.Length)]);
            }
            if (charPool.Count == 0)
            {
                Console.WriteLine("Error: No character types selected.");
                return "";
            }
            StringBuilder result = new StringBuilder();
            foreach (char c in guaranteedChars)
            {
                result.Append(c);
            }
            for (int i = guaranteedChars.Count; i < length; i++)
            {
                result.Append(charPool[rand.Next(charPool.Count)]);
            }
            return new string(result.ToString().OrderBy(x => rand.Next()).ToArray());
        }
    }
}